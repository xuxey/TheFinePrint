let myWindowId;

console.log('fineprint.js')

// document.getElementById('links-found').innerText = "lol hope this worked"